class CreateArticles < ActiveRecord::Migration[5.2]
  def change
    create_table :articles do |t|
      t.string :titulo
      t.string :subtitulo
      t.string :autor
      t.string :editorial
      t.string :ano_publicacion
      t.string :num_paginas

      t.timestamps
    end
  end
end
