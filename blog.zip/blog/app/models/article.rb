class Article < ActiveRecord::Base
  validates :titulo, :presence => true, length: {minimum:5}
  validates :subtitulo, :presence => true, length: {minimum:5}, :uniqueness => true
  validates :autor, :presence => true, length: {minimum:5}
  validates :editorial, :presence => true, length: {minimum:5}
  validates :ano_publicacion, :presence => true, length: {minimum:4}
  validates :num_paginas, :presence => true, length: {minimum:2}
end
